interface Props {
  setChartType: (val: 'bar' | 'line' | 'pie') => void;
}

export default function ChartTypeToggle({ setChartType }: Props) {
  return (
    <div className="flex space-x-2">
      <button onClick={() => setChartType('bar')} className="px-3 py-1 bg-blue-500 text-white rounded-md">Bar</button>
      <button onClick={() => setChartType('line')} className="px-3 py-1 bg-green-500 text-white rounded-md">Line</button>
      <button onClick={() => setChartType('pie')} className="px-3 py-1 bg-purple-500 text-white rounded-md">Pie</button>
    </div>
  );
}
