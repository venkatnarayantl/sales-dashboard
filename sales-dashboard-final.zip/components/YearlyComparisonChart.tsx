import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { monthlyData } from '../data/salesData';

export default function YearlyComparisonChart() {
  return (
    <div className="p-4 bg-white rounded-2xl shadow-md w-full">
      <h2 className="text-xl font-semibold mb-4">Monthly Sales Trend</h2>
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={monthlyData}>
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="sales" stroke="#8884d8" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
