import { useState } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { salesData } from '../data/salesData';
import FilterInput from './FilterInput';
import ChartTypeToggle from './ChartTypeToggle';

const COLORS = ['#8884d8', '#82ca9d', '#ffc658'];

export default function SalesChart() {
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie'>('bar');
  const [threshold, setThreshold] = useState(0);

  const filteredData = salesData.filter(item => item.sales >= threshold);

  return (
    <div className="p-4 bg-white rounded-2xl shadow-md w-full">
      <div className="flex justify-between mb-4">
        <FilterInput threshold={threshold} setThreshold={setThreshold} />
        <ChartTypeToggle setChartType={setChartType} />
      </div>

      <ResponsiveContainer width="100%" height={400}>
        {chartType === 'bar' && (
          <BarChart data={filteredData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="sales" fill="#8884d8" />
          </BarChart>
        )}
        {chartType === 'line' && (
          <LineChart data={filteredData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="sales" stroke="#82ca9d" />
          </LineChart>
        )}
        {chartType === 'pie' && (
          <PieChart>
            <Pie data={filteredData} dataKey="sales" nameKey="year" cx="50%" cy="50%" outerRadius={150}>
              {filteredData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
