interface Props {
  threshold: number;
  setThreshold: (val: number) => void;
}

export default function FilterInput({ threshold, setThreshold }: Props) {
  return (
    <input
      type="number"
      placeholder="Set sales threshold"
      value={threshold}
      onChange={e => setThreshold(Number(e.target.value))}
      className="border p-2 rounded-md w-full"
    />
  );
}
