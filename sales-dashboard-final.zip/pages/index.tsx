import Link from 'next/link';
import Navbar from '../components/Navbar';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="flex flex-col items-center justify-center py-24">
        <h1 className="text-5xl font-bold mb-6 text-blue-600">Welcome to Sales Dashboard</h1>
        <p className="text-lg mb-8">Track yearly and monthly sales with interactive charts.</p>
        <Link href="/dashboard">
          <span className="px-6 py-3 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 cursor-pointer">Go to Dashboard</span>
        </Link>
      </div>
    </div>
  );
}
