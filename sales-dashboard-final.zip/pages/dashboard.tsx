import Navbar from '../components/Navbar';
import SalesChart from '../components/SalesChart';
import YearlyComparisonChart from '../components/YearlyComparisonChart';
import DistributionChart from '../components/DistributionChart';

export default function Dashboard() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SalesChart />
        <YearlyComparisonChart />
        <DistributionChart />
      </div>
    </div>
  )
}
