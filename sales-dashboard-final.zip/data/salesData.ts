export const salesData = [
  { year: 2022, sales: 4200 },
  { year: 2023, sales: 6700 },
  { year: 2024, sales: 5400 },
];

export const monthlyData = [
  { month: "Jan", sales: 400 },
  { month: "Feb", sales: 350 },
  { month: "Mar", sales: 500 },
  { month: "Apr", sales: 600 },
  { month: "May", sales: 700 },
  { month: "Jun", sales: 650 },
];
